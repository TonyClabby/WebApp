var express = require("express");//the app need the express module so it will work
var app = express();//invoke express application
var fs = require('fs');


var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({extended: true}));


//we need some way for the app to know where to look


app.use(express.static("views"));
app.use(express.static("scripts"));


var contact = require("./model/comment.json"); //provides access to the json file


//set up a page that just says something
app.get("/", function(req,res){
    
    res.render("index.ejs");
    console.log("on home (index) page");
    
});

//products becomes list
//route to render the products page
app.get("/list", function(req,res){
    
    res.render("list.ejs");
    console.log("on list page");
    
});

//contatcts stays the same
//route to render contact info page
app.get("/contact", function(req,res){
    
    res.render("contact.ejs", {contact});
    console.log("on contact page");
    
});

//addcontact => sell
//route to render add contact page
app.get("/sell", function(req,res){
    
    res.render("sell.ejs", {contact});
    console.log("on sell house page");
    
})

app.get("/comment", function(req,res){
    
    res.render("comment.ejs", {contact});
    console.log("on comment page");
    
});



app.get("/buy", function(req,res){
    
    res.render("buy.ejs", {contact});
    console.log("on contact page");
    
});


//url to delete JSON
app.get("/deletecontact/:id", function(req, res){
        
  var json = JSON.stringify(contact); // Convert our json data to a string
  
  var keyToFind = parseInt(req.params.id) // Getes the id from the URL
  var data = contact; // Tell the application what the data is
  var index = data.map(function(d) {return d.id;}).indexOf(keyToFind)
  console.log("variable Index is : " + index)
  console.log("The Key you ar looking for is : " + keyToFind);
  
  contact.splice(index, 1);
  json = JSON.stringify(contact, null, 4); // converts the data to a json file and the null and 4 represent how it is structuere. 4 is indententation 
      fs.writeFile('./model/contact.json', json, 'utf8')
  res.redirect("/contact");
    

})


//render edit contacts page
app.get("/addcomment/:id", function(req,res){
    
    
    res.render("addcomment.ejs", {contact});
    
    
});

// now we need to tell the app where to run
app.listen(process.env.PORT || 3000, process.env.IP || "0.0.0.0", function() {
console.log("Here we go again");
})